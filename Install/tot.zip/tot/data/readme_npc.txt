NPC-specific data files can be found in \data\npc\

One folder per NPC.

Currently, ToT only supports the single, default, NPC.

This will change in the next version. :)

PAF