
The \shop\ folder contains all of the shop data

========================================================================
========================================================================
== Shop ================================================================
========================================================================
========================================================================


Folder format

\shop\top level shop name\sub-category_name.txt contains shop items.


File names cannot contain the / symbol, however, if you need this symbol (as in "Dungeons / Locations"), then use a double underscore __. The application will replace them automatically!


========================================================================
== Structure ===========================================================
========================================================================

Comments start with either a / or a ;

{
n:Item name
d:Description
c:Item cost cp/sp/gp/pp
z:Indicate range of values (optional)
a:Armour class
h:Stealth
s:Strength
m:Damage
w:Weight
p:Properties
}

All items are optional, though the more that are filled in the more
useful the data will be to any DM.


========================================================================
==                                                                    ==
========================================================================

- Paul A Freshney, August 17th 2017
  paul@freshney.org

========================================================================
==                                                                    ==
========================================================================


